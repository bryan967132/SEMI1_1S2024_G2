import os
import mysql.connector

class MySQL:
    def __init__(self):
        self.conexion = mysql.connector.connect(
            host="proyecto-semi1.c7gm4e482f9t.us-east-2.rds.amazonaws.com",
            user="admin",
            password="IHQCK05YT9zh51xZGSYWAA",
            database="proyecto",
            port=3306
        )
        self.cursor = self.conexion.cursor()

    def mis_favoritos(self, usuario):
        try:
            query_favoritos = f'''
            SELECT recurso.*
            FROM proyecto.RECURSO recurso
            INNER JOIN proyecto.FAVORITO favorito ON recurso.id = favorito.id_recurso
            INNER JOIN proyecto.USUARIO usuario ON favorito.id_usuario = usuario.id
            WHERE usuario.usuario = '{usuario}';
            '''
            self.cursor.execute(query_favoritos)
            favoritos = self.cursor.fetchall()
            response = f"Los recursos favoritos de {usuario}:"
            for i in range(len(favoritos)):
                response += ('\n' if response != '' else '') + f'\n{i + 1}. {favoritos[i][1]}'
        
            return [{'contentType': 'PlainText', 'content': response}]
            
        except Exception as e:
            print(e)
            return []
    
    def get_categoria(self):
        try:
            query_categoria = f'''
            SELECT categoria FROM proyecto.CATEGORIA;
            '''
            self.cursor.execute(query_categoria)
            categorias = self.cursor.fetchall()
            response = f"Categorias:"
            for i in range(len(categorias)):
                response += ('\n' if response != '' else '') + f'\n{i + 1}. {categorias[i][0]}'
            return [{'contentType': 'PlainText', 'content': response}]
            
        except Exception as e:
            print(e)
            return []
        
    def get_recomendaciones(self,usuario,tipo,categoria):
        try:
            query_recomendaciones = f'''
            SELECT r.titulo, AVG(c.punteo) AS promedio_calificacion
            FROM proyecto.RECURSO r
            JOIN proyecto.CALIFICACION c ON r.id = c.id_recurso
            JOIN proyecto.CATEGORIA cat ON r.id_categoria = cat.id
            WHERE cat.categoria = '{categoria}' AND r.tipo = '{tipo}'
            GROUP BY r.titulo
            ORDER BY promedio_calificacion DESC
            LIMIT 3;
            '''
            self.cursor.execute(query_recomendaciones)
            recomendaciones = self.cursor.fetchall()
            response = f"Mejores {tipo} de {categoria}:"
            for i in range(len(recomendaciones)):
                response += ('\n' if response != '' else '') + f'\n{i + 1}. {recomendaciones[i][0]} con una calificacion: {recomendaciones[i][1]} ✯'
        
            return [{'contentType': 'PlainText', 'content': response}]
            
        except Exception as e:
            print(e)
            return []