from MySQL import MySQL

bd = MySQL()

def validate(intent, slots):
    if not slots['Usuario']:
        return {
            'isValid': False,
            'violatedSlot': 'Usuario',
        }
    
    if intent == 'Recomendaciones':
        if not slots['Tipo']:
            return {
                'isValid': False,
                'violatedSlot': 'Tipo',
            }
            
        if not slots['Categoria']:
            return {
                'isValid': False,
                'violatedSlot': 'Categoria'
            }
  
    return {'isValid': True}

def routeQuery(intent, slots):
    global bd
    if intent == 'MisFavoritos':
        return bd.mis_favoritos(
            slots['Usuario']['value']['originalValue']
        )
    if intent == 'Recomendaciones':
        return bd.get_recomendaciones(
            slots['Usuario']['value']['originalValue'],
            slots['Tipo']['value']['originalValue'],
            slots['Categoria']['value']['originalValue']
        )
    return []


def lambda_handler(event, context):
    global bd
    slots = event['sessionState']['intent']['slots']
    intent = event['sessionState']['intent']['name']
    print(event['invocationSource'])
    validation_result = validate(intent, slots)

    if event['invocationSource'] == 'DialogCodeHook':
        if not validation_result['isValid']:
            response = {
                'sessionState': {
                    'dialogAction': {
                        'slotToElicit': validation_result['violatedSlot'],
                        'type': 'ElicitSlot'
                    },
                    'intent': {
                        'name': intent,
                        'slots': slots
                    }
                }
            }
            if validation_result['violatedSlot'] == 'Categoria':
                response['messages'] = [{
                    "contentType": "PlainText",
                    "content": "¿Qué Categoria?"
                }] + bd.get_categoria()
        else:
            response = {
                'sessionState': {
                    'dialogAction': {
                        'type': 'Delegate'
                    },
                    'intent': {
                        'name': intent,
                        'slots': slots
                    }
                }
            }
        return response
    if event['invocationSource'] == 'FulfillmentCodeHook':
        responseQuery = routeQuery(intent, slots)
        response = {
            "sessionState": {
                "dialogAction": {
                    "type": "Close"
                },
                "intent": {
                    'name':intent,
                    'slots': slots,
                    'state':'Fulfilled'
                }
            },
            "messages": responseQuery + [
                {
                    "contentType": "PlainText",
                    "content": "¡Fue un placer haberte ayudado!"
                }
            ]
        }
    
    return response
            
    
    